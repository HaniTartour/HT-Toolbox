# -*- coding: utf-8 -*-
# script.py
# Launch the About BIMBuddy Windows Form

import about_form

form = about_form.AboutBIMBuddyForm()
form.ShowDialog()
